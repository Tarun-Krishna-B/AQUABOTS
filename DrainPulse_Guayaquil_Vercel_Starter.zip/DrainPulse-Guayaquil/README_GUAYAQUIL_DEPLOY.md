# DrainPulse Guayaquil — HACK2IMPACT Track 1

Adaptation of the supplied AquaBots React/Vite app for the HACK2IMPACT 2026 Track 1 challenge: Heavy Rain & Flood Resilience in Guayaquil, Ecuador. The language selector is limited to Spanish and English. The map and seed incident coordinates are moved to the Guayaquil area; risk-zone values and sample telemetry are demo data, not official live flood measurements.

## Deploy frontend to Vercel
1. Push this folder's contents to a new GitHub repository (do not push `.env` files or secrets).
2. In Vercel, choose **Add New → Project**, import the repository, and use the repository root as the Root Directory.
3. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`. Install command: `npm install`.
4. Deploy. `vercel.json` supplies the SPA rewrite for direct navigation.

## Important backend note
The repository contains a separate Express API in `/server`. Vercel's static frontend deployment alone does not deploy that API. Without a separately hosted API, the dashboard can show its seeded/demo data, but actions that submit reports or persist server-side updates may not work. To enable those, deploy `/server` to a Node-capable host, configure its MongoDB connection and CORS origins, then set `VITE_API_BASE_URL` in Vercel to the deployed API base URL ending in `/api`, and redeploy. Never expose MongoDB credentials in `VITE_` variables.

## Track 1 demo checklist
- Show at least five simulated waterlogging nodes on the map (label them clearly as simulated).
- Demonstrate flood-aware routing that avoids high-risk segments.
- Demonstrate an alert dispatch flow.
- Explain that real Guayaquil sensor feeds, official road closures, elevation data, and rainfall API integration still require verified data/API configuration.
