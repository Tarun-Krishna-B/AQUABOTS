export type CoverageLevel = 'full' | 'core' | 'partial';
export type LanguageCategory = 'indian' | 'international';
export interface LanguageMeta { code: string; name: string; nativeName: string; category: LanguageCategory; isRtl?: boolean; coverage: CoverageLevel; coveragePercent: number; region: string; }
export const LANGUAGES: LanguageMeta[] = [
  { code: 'en', name: 'English', nativeName: 'English', category: 'international', coverage: 'full', coveragePercent: 100, region: 'International' },
  { code: 'es', name: 'Español', nativeName: 'Español', category: 'international', coverage: 'full', coveragePercent: 100, region: 'Ecuador / Guayaquil' }
];
export const getLanguageMeta = (code: string): LanguageMeta => {
  const normalized = code.toLowerCase().split('-')[0];
  return LANGUAGES.find(l => l.code === normalized) || LANGUAGES[0];
};
